// D R TEXTILES — frontend controller
// Configure API_BASE to your deployed FastAPI URL before production.
const API_BASE = localStorage.getItem("DR_API_BASE") || "http://127.0.0.1:8000";
let adminToken = localStorage.getItem("DR_ADMIN_TOKEN") || "";
const $ = (id) => document.getElementById(id);
let personFile = null, sareeFile = null, selectedStyle = "pleated", cameraStream = null;
let tryonCount = 0, generatedCount = 0;
const catalogue = [];

function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 2800);
}
function previewFile(file, imgEl) {
  if (!file) return;
  if (!file.type.startsWith("image/")) return toast("Please choose an image file.");
  const url = URL.createObjectURL(file); imgEl.src = url; imgEl.classList.remove("hidden");
}
$("personInput").addEventListener("change", e => {
  personFile = e.target.files[0] || null; previewFile(personFile, $("personPreview"));
});
$("sareeInput").addEventListener("change", e => {
  sareeFile = e.target.files[0] || null; previewFile(sareeFile, $("sareePreview"));
});
document.querySelectorAll(".style-option").forEach(btn => btn.addEventListener("click", () => {
  document.querySelectorAll(".style-option").forEach(x => x.classList.remove("selected"));
  btn.classList.add("selected"); selectedStyle = btn.dataset.style;
}));
document.querySelectorAll(".tab").forEach(btn => btn.addEventListener("click", async () => {
  document.querySelectorAll(".tab").forEach(x => x.classList.remove("active")); btn.classList.add("active");
  const cameraMode = btn.dataset.tab === "camera";
  $("sareeDrop").classList.toggle("hidden", cameraMode); $("cameraBox").classList.toggle("hidden", !cameraMode);
  if (cameraMode) {
    try {
      cameraStream = await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment"},audio:false});
      $("cameraVideo").srcObject = cameraStream;
    } catch (err) { toast("Camera unavailable. Check permission or use image upload."); }
  } else stopCamera();
}));
function stopCamera() { if (cameraStream) cameraStream.getTracks().forEach(t => t.stop()); cameraStream = null; }
$("captureSaree").addEventListener("click", () => {
  const video = $("cameraVideo"); if (!video.videoWidth) return toast("Camera is not ready yet.");
  const canvas = document.createElement("canvas"); canvas.width = video.videoWidth; canvas.height = video.videoHeight;
  canvas.getContext("2d").drawImage(video,0,0);
  canvas.toBlob(blob => { sareeFile = new File([blob], "captured-saree.jpg", {type:"image/jpeg"}); previewFile(sareeFile,$("sareePreview")); $("sareeDrop").classList.remove("hidden"); $("cameraBox").classList.add("hidden"); document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x.dataset.tab==="upload")); stopCamera(); }, "image/jpeg", .92);
});
$("catalogueInput").addEventListener("change", e => {
  [...e.target.files].forEach(file => {
    if (!file.type.startsWith("image/")) return;
    const item = {id:crypto.randomUUID(),file,name:file.name,url:URL.createObjectURL(file)};
    catalogue.push(item); renderCatalogue();
  });
  $("catalogueCount").textContent = catalogue.length; e.target.value = "";
});
function renderCatalogue() {
  const grid = $("catalogueGrid");
  if (!catalogue.length) { grid.innerHTML = '<div class="empty-state">Your catalogue is waiting for its first saree. Add an image to begin.</div>'; return; }
  grid.innerHTML = catalogue.map(item => `<article class="catalogue-item"><img src="${item.url}" alt="Saree catalogue image"><p>${escapeHtml(item.name)}</p><button data-use="${item.id}">Use for try-on</button> · <button data-remove="${item.id}">Remove</button></article>`).join("");
  grid.querySelectorAll("[data-use]").forEach(btn => btn.addEventListener("click", () => {
    const item = catalogue.find(x=>x.id===btn.dataset.use); if (!item) return;
    sareeFile = item.file; previewFile(sareeFile,$("sareePreview")); $("sareeDrop").classList.remove("hidden"); $("sareeInput").value = ""; location.hash="#tryon"; toast("Catalogue saree selected.");
  }));
  grid.querySelectorAll("[data-remove]").forEach(btn => btn.addEventListener("click", () => {
    const i = catalogue.findIndex(x=>x.id===btn.dataset.remove); if(i>=0){URL.revokeObjectURL(catalogue[i].url);catalogue.splice(i,1);renderCatalogue();$("catalogueCount").textContent=catalogue.length;}
  }));
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}

$("generateBtn").addEventListener("click", generateTryOn);
async function generateTryOn() {
  toast("AI try-on is reserved for a future upgrade. Your photos are not uploaded or processed.");
}
$("generateBtn").addEventListener("click", generateTryOn);

function addHistory(url,style) {
  const item=document.createElement("div");item.className="history-item";
  const img=document.createElement("img");img.src=url;img.alt="Generated look";
  const text=document.createElement("div");const strong=document.createElement("strong");strong.textContent="Virtual saree look";
  const small=document.createElement("small");small.textContent=`${style==="open"?"Open pallu":"Pleated pallu"} · ${new Date().toLocaleTimeString()}`;
  text.append(strong,small);item.append(img,text);$("historyList").prepend(item);
}
$("newTryonBtn").addEventListener("click",()=>{ $("resultSection").classList.add("hidden"); $("personInput").value=""; $("sareeInput").value=""; personFile=null;sareeFile=null;$("personPreview").classList.add("hidden");$("sareePreview").classList.add("hidden");window.scrollTo({top:$("tryon").offsetTop-20,behavior:"smooth"});});
window.addEventListener("beforeunload",stopCamera);

// Public preview mode: this site has no private admin authentication or AI service enabled.
// Do not upload real customer photographs or confidential catalogue material to this preview.
document.addEventListener("DOMContentLoaded", () => {
  const note=document.createElement("div");
  note.textContent="PUBLIC PREVIEW • AI generation, secure QR sharing and private admin login will be activated in a later setup.";
  note.style.cssText="background:#fff4df;border:1px solid #e8d2a9;color:#684d2d;padding:10px 14px;border-radius:8px;font-size:11px;margin:18px 0 0;line-height:1.5";
  document.querySelector(".topbar").after(note);
});
