# D R TEXTILES — Free public web preview

This is a static preview build designed for a free public website link.

## Deploy free with Netlify Drop

1. Extract this ZIP.
2. Open https://app.netlify.com/drop
3. Sign in / create a free Netlify account.
4. Drag the extracted `DR_Textiles_Free_Web_Preview` folder onto the drop area.
5. Netlify publishes it and gives you a public `*.netlify.app` URL.
6. Share that URL with anyone.

Netlify's free plan currently offers $0 hosting, subject to its monthly credit/usage limits. Check its current pricing and usage rules before wider distribution.

## What works in this preview

- Royal D R TEXTILES dashboard
- Responsive desktop/mobile layout
- Customer photo selection and local preview
- Saree image selection and local camera capture (browser permission required)
- Pleated/open pallu selection
- Temporary in-browser catalogue previews
- Navigation and session UI

## What is deliberately not active yet

- Actual AI saree transformation
- Customer QR download links
- Secure admin login
- Persistent catalogue / cloud storage
- Real customer image processing

The preview clearly displays this limitation. Do not upload real customer photos or confidential catalogue material to a public preview.

## Next stage

When ready, connect a secure backend, authentication, private image storage, an AI provider, expiring QR links and then build Android / Windows installers.
